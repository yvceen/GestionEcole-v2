<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // 1) add column only if not exists
        if (!Schema::hasColumn('parent_student_fees', 'school_id')) {
            Schema::table('parent_student_fees', function (Blueprint $table) {
                $table->unsignedBigInteger('school_id')->nullable()->after('id');
            });
        }

        // 2) backfill: from students.school_id (best source)
        DB::statement("
            UPDATE parent_student_fees pf
            JOIN students s ON s.id = pf.student_id
            SET pf.school_id = s.school_id
            WHERE pf.school_id IS NULL
        ");

        // 3) make NOT NULL (بدون change())
        DB::statement("ALTER TABLE parent_student_fees MODIFY school_id BIGINT UNSIGNED NOT NULL");

        // 4) add index if not exists
        try {
            DB::statement("CREATE INDEX parent_student_fees_school_id_index ON parent_student_fees (school_id)");
        } catch (\Throwable $e) {
            // index already exists => ignore
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('parent_student_fees', 'school_id')) {
            try {
                DB::statement("DROP INDEX parent_student_fees_school_id_index ON parent_student_fees");
            } catch (\Throwable $e) {
                // ignore
            }

            Schema::table('parent_student_fees', function (Blueprint $table) {
                $table->dropColumn('school_id');
            });
        }
    }
};
