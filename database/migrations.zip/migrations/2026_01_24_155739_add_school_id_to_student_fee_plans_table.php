<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // 1) add column only if not exists
        if (!Schema::hasColumn('student_fee_plans', 'school_id')) {
            Schema::table('student_fee_plans', function (Blueprint $table) {
                $table->unsignedBigInteger('school_id')->nullable()->after('id');
            });
        }

        // 2) backfill from students.school_id
        DB::statement("
            UPDATE student_fee_plans sf
            JOIN students s ON s.id = sf.student_id
            SET sf.school_id = s.school_id
            WHERE sf.school_id IS NULL
        ");

        // 3) make it NOT NULL (بدون change() باش ما نحتاجوش doctrine/dbal)
        DB::statement("ALTER TABLE student_fee_plans MODIFY school_id BIGINT UNSIGNED NOT NULL");

        // 4) add index if not exists (safe try/catch)
        try {
            DB::statement("CREATE INDEX student_fee_plans_school_id_index ON student_fee_plans (school_id)");
        } catch (\Throwable $e) {
            // index already exists => ignore
        }
    }

    public function down(): void
    {
        // drop index + column only if exists
        if (Schema::hasColumn('student_fee_plans', 'school_id')) {
            try {
                DB::statement("DROP INDEX student_fee_plans_school_id_index ON student_fee_plans");
            } catch (\Throwable $e) {
                // ignore
            }

            Schema::table('student_fee_plans', function (Blueprint $table) {
                $table->dropColumn('school_id');
            });
        }
    }
};
